# hello

Minimal example of a two parties "alice" and "bob" exchanging a shared
secret with KEM512, KEM768, and KEM1024.

**Note:** This example is used as a source for examples in the generated
API documentation.

## Build

Type `make`.
