Miscellaneous scripts used to generate and test code in the top-level
file `fips203ipd.c`.
